/**
 * 益智游戏 - 应用入口
 * 首页地图、关卡选择、页面路由
 */

class App {
  constructor() {
    this.currentPage = 'home';
    this.currentPlanet = null;
    this.progress = null;
  }

  /**
   * 初始化应用
   */
  init() {
    console.log('应用初始化...');

    // 加载进度
    this.progress = gameStorage.getProgress();

    // 初始化UI
    uiManager.init();

    // 绑定事件
    this.bindEvents();

    // 渲染首页
    this.renderHomePage();

    // 隐藏音频提示(如果已解锁)
    if (audioManager.unlocked) {
      const audioHint = document.getElementById('audio-hint');
      if (audioHint) {
        audioHint.style.display = 'none';
      }
    }

    console.log('应用初始化完成');
  }

  /**
   * 绑定事件
   */
  bindEvents() {
    // 家长按钮
    const parentBtn = document.getElementById('parent-btn');
    if (parentBtn) {
      parentBtn.addEventListener('click', () => {
        this.navigateToParent();
      });
    }

    // 徽章按钮
    const badgeBtn = document.getElementById('badge-btn');
    if (badgeBtn) {
      badgeBtn.addEventListener('click', () => {
        uiManager.showToast('徽章墙功能即将开放!');
      });
    }

    // 返回按钮
    const backBtn = document.getElementById('back-to-home');
    if (backBtn) {
      backBtn.addEventListener('click', () => {
        this.navigateHome();
      });
    }

    // 星球点击
    const planetItems = document.querySelectorAll('.planet-item');
    planetItems.forEach(item => {
      item.addEventListener('click', (e) => {
        const planet = item.dataset.planet;
        this.handlePlanetClick(planet, item);
      });
    });
  }

  /**
   * 渲染首页
   */
  renderHomePage() {
    // 更新统计
    this.updateStats();

    // 更新星球状态
    this.updatePlanetStatus();
  }

  /**
   * 更新统计信息
   */
  updateStats() {
    const totalStars = document.getElementById('total-stars');
    const completedLevels = document.getElementById('completed-levels');

    if (totalStars) {
      totalStars.textContent = this.progress.stats.totalStars;
    }

    if (completedLevels) {
      // 计算完成关卡数
      let completed = 0;
      Object.keys(this.progress.levels).forEach(levelId => {
        if (this.progress.levels[levelId].status === 'completed') {
          completed++;
        }
      });
      completedLevels.textContent = completed;
    }
  }

  /**
   * 更新星球状态
   */
  updatePlanetStatus() {
    // 颜色星球
    const colorStats = gameStorage.getPlanetStats('color');
    const colorStars = document.getElementById('color-stars');
    if (colorStars) {
      colorStars.textContent = colorStats.totalStars;
    }

    // 形状星球 - 检查是否解锁
    const shapePlanet = document.querySelector('[data-planet="shape"]');
    if (shapePlanet) {
      const isUnlocked = gameStorage.checkPlanetUnlock(this.progress, 'shape');
      if (isUnlocked) {
        shapePlanet.classList.remove('locked');
      }
    }

    // 数字星球 - 检查是否解锁
    const numberPlanet = document.querySelector('[data-planet="number"]');
    if (numberPlanet) {
      const isUnlocked = gameStorage.checkPlanetUnlock(this.progress, 'number');
      if (isUnlocked) {
        numberPlanet.classList.remove('locked');
      }
    }
  }

  /**
   * 处理星球点击
   */
  handlePlanetClick(planet, element) {
    // 检查是否锁定
    if (element.classList.contains('locked')) {
      uiManager.showToast('这个星球还未解锁哦!');
      audioManager.playError();
      return;
    }

    // 只有颜色星球在MVP阶段可用
    if (planet !== 'color') {
      uiManager.showToast('这个星球即将开放!');
      return;
    }

    this.currentPlanet = planet;
    this.navigateToLevelSelect(planet);
  }

  /**
   * 导航到关卡选择页面
   */
  navigateToLevelSelect(planet) {
    const homePage = document.getElementById('home-page');
    const levelSelectPage = document.getElementById('level-select-page');

    if (!homePage || !levelSelectPage) return;

    // 更新标题
    const planetTitle = document.getElementById('planet-title');
    if (planetTitle) {
      const planetNames = {
        'color': '颜色星球',
        'shape': '形状星球',
        'number': '数字星球'
      };
      planetTitle.textContent = planetNames[planet] || '未知星球';
    }

    // 渲染关卡列表
    this.renderLevelList(planet);

    // 切换页面
    homePage.classList.remove('active');
    levelSelectPage.classList.add('active');

    // 绑定关卡点击事件
    this.bindLevelClickEvents();
  }

  /**
   * 渲染关卡列表
   */
  renderLevelList(planet) {
    const levels = [];

    // 获取该星球的所有关卡
    for (let i = 1; i <= 5; i++) {
      const levelId = `${planet}_${i}`;
      const levelData = this.progress.levels[levelId];

      if (levelData) {
        levels.push({
          id: levelId,
          name: this.getLevelName(planet, i),
          status: levelData.status,
          bestStars: levelData.bestStars
        });
      }
    }

    uiManager.renderLevelList(levels, planet);
  }

  /**
   * 获取关卡名称
   */
  getLevelName(planet, level) {
    const levelNames = {
      'color': ['基础色识别', '颜色分类', '颜色配对', '深浅色区分', '综合挑战'],
      'shape': ['基础形状', '形状分类', '形状配对', '形状组合', '综合挑战'],
      'number': ['认识数字', '数数', '比较大小', '简单加法', '综合挑战']
    };

    if (levelNames[planet] && levelNames[planet][level - 1]) {
      return levelNames[planet][level - 1];
    }

    return `第${level}关`;
  }

  /**
   * 绑定关卡点击事件
   */
  bindLevelClickEvents() {
    const levelCards = document.querySelectorAll('.level-card');

    levelCards.forEach(card => {
      card.addEventListener('click', () => {
        const levelId = card.dataset.levelId;
        this.handleLevelClick(levelId, card);
      });
    });
  }

  /**
   * 处理关卡点击
   */
  handleLevelClick(levelId, element) {
    // 检查是否锁定
    if (element.classList.contains('locked')) {
      uiManager.showToast('这一关还未解锁哦!');
      audioManager.playError();
      return;
    }

    // 跳转到游戏页面
    this.navigateToGame(levelId);
  }

  /**
   * 导航到游戏页面
   */
  navigateToGame(levelId) {
    // 将levelId传递给游戏页面
    window.location.href = `game.html?level=${levelId}`;
  }

  /**
   * 导航到家长面板
   */
  navigateToParent() {
    window.location.href = 'parent.html';
  }

  /**
   * 导航回首页
   */
  navigateHome() {
    const homePage = document.getElementById('home-page');
    const levelSelectPage = document.getElementById('level-select-page');

    if (!homePage || !levelSelectPage) return;

    levelSelectPage.classList.remove('active');
    homePage.classList.add('active');

    // 重新渲染首页
    this.renderHomePage();
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  const app = new App();
  app.init();

  // 暴露到全局
  window.app = app;
});
